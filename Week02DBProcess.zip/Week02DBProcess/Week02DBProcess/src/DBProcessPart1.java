//import for sql Connection, DriverManager, ResultSet, Statement
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;


/**
 * Abstract: DBProcessPart1 - loads the data from the table and I have to pass args using run confids
 * @author Nick
 * @since 1/24/2025
 * @version 1.0
 */
public class DBProcessPart1 
{

	//define the Connection
	private static Connection m_conAdministrator;
	//define the table, primary key, and column
	private static String strTable;
	private static String strPrimaryKey;
	private static String strColumn;
	
	
	/**
	 * Main method that initializes database processing.
	 * @param args Command-line arguments: table name, primary key column, and data column.
	 */
	public static void main(String[] args) 
	{
		// Check if correct arguments are passed
        if (args.length != 3) 
        {
            System.out.println("Since you did not pass your table, primary key, and column – cannot process");
            return;  
        }
		
        // Get args passed during Run Configuration
        strTable = args[0]; 
        strPrimaryKey = args[1];
        strColumn = args[2];
        try {
        	
			// Can we connect to the database?
			if ( OpenDatabaseConnectionSQLServer( ) == true )
			{	
				// Yes, load the teams list
				LoadListFromDatabase( "TEmployees", "intEmployeeID" , "strFirstName" );
			}
			else
			{
				// No, warn the user ...
				System.out.println("Error loading the table");
			}
			
		System.out.println("Process Complete");
    }
        catch 	(Exception e) {
        	System.out.println("An I/O error occurred: " + e.getMessage());
    	}           
    }

	/**
	 * This will load the list from the table.
	 * @param strTable The table name
	 * @param strPrimaryKeyColumn The primary key column
	 * @param strNameColumn The column to fetch
	 * @return boolean indicating success or failure
	 */
	public static boolean LoadListFromDatabase( String strTable, String strPrimaryKeyColumn, String strNameColumn ) {
		
		//set flag to false
		boolean blnResult = false;
		
		try
		{
			String strSelect = "";
			Statement sqlCommand = null;
			ResultSet rstTSource = null;
			int intID = 0;
			String strName = "";
		
			// Build the SQL string
			strSelect = "SELECT " + strPrimaryKeyColumn + ", " + strNameColumn
						+ " FROM " + strTable
						+ " ORDER BY " + strNameColumn; 
					
			// Retrieve the all the records	
			sqlCommand = m_conAdministrator.createStatement( );
			rstTSource = sqlCommand.executeQuery( strSelect );
			// Loop through all the records
			while( rstTSource.next( ) == true )
			{
				// Get ID and Name from current row
				intID = rstTSource.getInt( 1 );
				strName = rstTSource.getString( 2 );
				// Print the list
				System.out.println("Table is: " + strTable + " Primary key: " + intID + " strName: " + strName);
			}
			// Clean up
			rstTSource.close( );
			sqlCommand.close( );			
			// Success
			blnResult = true;
		}
		catch 	(Exception e) {
			System.out.println( "Error loading table" );
			System.out.println( "Error is " + e );
		}
		
		return blnResult;
		}
			
    /**
     * Open a connection to the SQL Server database.
     * @return boolean indicating success or failure
     */
	public static boolean OpenDatabaseConnectionSQLServer( )
	{
		boolean blnResult = false;
		
		try
		{
			SQLServerDataSource sdsTeamsAndPlayers = new SQLServerDataSource( );
			//tg-comment out --sdsTeamsAndPlayers.setServerName( "localhost" ); // localhost or IP or server name
			sdsTeamsAndPlayers.setServerName( "localhost\\SQLExpress" ); // SQL Express version
			sdsTeamsAndPlayers.setPortNumber( 1433 );
			sdsTeamsAndPlayers.setDatabaseName( "dbHCM" );
			
			// Login Type:
			
				// Windows Integrated
				//tg-comment out --sdsTeamsAndPlayers.setIntegratedSecurity( true );
				
				// OR
				
				// SQL Server
			     sdsTeamsAndPlayers.setUser( "sa" );
				 sdsTeamsAndPlayers.setPassword( "AizenIsCool1" );	// Empty string "" for blank password
			
			// Open a connection to the database
			m_conAdministrator = sdsTeamsAndPlayers.getConnection(  );
			
			// Success
			blnResult = true;
		}
		catch( Exception excError )
		{
			// Display Error Message
			System.out.println( "Cannot connect - error: " + excError );

			// Warn about SQL Server JDBC Drivers
			System.out.println( "Make sure download MS SQL Server JDBC Drivers");
		}
		
		return blnResult;
	}
	
	/**
	 * Name: CloseDatabaseConnection
	 * Abstract: Close the connection to the database
	 * @return boolean indicating success or failure
	 */ 
	public static boolean CloseDatabaseConnection( )
	{
		boolean blnResult = false;
		
		try
		{
			// Is there a connection object?
			if( m_conAdministrator != null )
			{
				// Yes, close the connection if not closed already
				if( m_conAdministrator.isClosed( ) == false ) 
				{
					m_conAdministrator.close( );
					
					// Prevent JVM from crashing
					m_conAdministrator = null;
				}
			}
			// Success
			blnResult = true;
		}
		catch( Exception excError )
		{
			// Display Error Message
			System.out.println( excError );
		}
		
		return blnResult;
	}

}

